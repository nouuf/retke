from django.shortcuts import render, redirect
from django.contrib import messages
import bcrypt
from .models import User, Job



def index(request):
    return render(request, 'index.html')

def register(request):
    if request.method == "POST":
        errors = User.objects.register_validator(request.POST)
        if len(errors) > 0:
            for key, value in errors.items():
                messages.error(request, value)
            return redirect("/")
        password = request.POST['password']
        pw_hash = bcrypt.hashpw(
            password.encode(), bcrypt.gensalt()).decode()  # create the hash
        new_user = User.objects.create(
            first_name=request.POST['first_name'],
            last_name=request.POST['last_name'],
            email=request.POST['email'],
            password=pw_hash)
        request.session['user_id'] = new_user.id
        return redirect("/dashboard")  # never render on a post, always redirect!

def login(request):
    if request.method == "POST":
        errors = User.objects.login_validator(request.POST)
        if len(errors) > 0:
            for key, value in errors.items():
                messages.error(request, value)
            return redirect("/")
        logged_user = User.objects.get(email=request.POST['email'])
        request.session['user_id'] = logged_user.id
        return redirect('/dashboard')
    return redirect("/")

def logout(request):
    request.session.flush()
    return redirect("/")


def jobs(request):
    if 'user_id' not in request.session:
        return redirect('/')
    #exclude Returns a new QuerySet containing objects that do not match the given lookup parameters.
    user = User.objects.get(id=request.session['user_id'])
    usersjob = user.useraddjob.all()
    all_jobs = Job.objects.exclude(id__in=usersjob)

    context = {
        'user': user,
        'all_jobs': all_jobs,
        'add_job':usersjob,
    }

    return render(request, 'dashboard.html', context)

def add_job(request):
    if 'user_id' not in request.session:
        return redirect('/')
        
    user = User.objects.get(id=request.session['user_id'])
    

    context = {
        'user': user,
        
    }

    return render(request, 'add_job.html', context)

def create_job(request):
    #errs = Trip.objects.trip_validator(request.POST)
    if request.method == "POST":
        errors = Job.objects.job_validator(request.POST)
        if len(errors) > 0:
            for key, value in errors.items():
                messages.error(request, value)
            return redirect("/jobs/add")
            print("errors have been found")
    Job.objects.create(
        title=request.POST['title'],
        description=request.POST['description'],
        location=request.POST['location'],  
        created_by_user=User.objects.get(id=request.session['user_id']), )
    return redirect('/dashboard')
   


def edit(request, id):
    context = {
        'job': Job.objects.get(id=id),
    }
    return render(request, 'edit_job.html', context)


def update(request,id):
    job = Job.objects.get(id=id)
    if request.method == "POST":
        errors = Job.objects.job_validator(request.POST)
        if len(errors) > 0:
            for key, value in errors.items():
                messages.error(request, value)
            return redirect(f'/jobs/{job.id}/edit')
    job.title=request.POST['title']
    job.description=request.POST['description']
    job.location=request.POST['location']
    job.save()
    #return redirect(f'/jobs/show/{trip.id}')

    return redirect('/dashboard')

def view(request, id):
    
    if 'user_id' not in request.session:
        return redirect('/')

    user = User.objects.get(id=request.session['user_id'])
    job = Job.objects.get(id = id)
    usersjob = user.useraddjob.all()
    all_jobs = Job.objects.exclude(id__in=usersjob)
    
    context = {
        'user': user,
        'all_jobs': all_jobs,
        'usersjob': usersjob,
        'job': job,
    }

    return render(request, 'view_job.html', context)

def delete(request,id):
    if 'user_id' not in request.session:

        return redirect('/')
    user = User.objects.get(id=request.session['user_id'])
    job = Job.objects.get(id = id)
    if job.created_by_user != user:
        return redirect('/dashboard')
    job.delete()
    return redirect('/dashboard')

def add_to_user(request,id):
    if 'user_id' not in request.session:
        return redirect('/')
    user = User.objects.get(id=request.session['user_id'])
    job = Job.objects.get(id =id)
    user.useraddjob.add(job)
    return redirect('/dashboard')

def remove(request,id):
    if 'user_id' not in request.session:
        return redirect('/')

    user = User.objects.get(id=request.session['user_id'])
    job = Job.objects.get(id = id)
    user.useraddjob.remove(job)
    return redirect('/dashboard')

def done(request, id):
    if 'user_id' not in request.session:
        return redirect('/')
    user = User.objects.get(id=request.session['user_id'])
    job = Job.objects.get(id = id)
    if user not in job.useraddjob.all():
        return redirect('/dashboard')
    job.delete()
    return redirect('/dashboard')