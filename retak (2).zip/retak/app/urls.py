from django.urls import path     
from . import views

urlpatterns = [
    path('', views.index),
    path('register', views.register),
    path('login',views.login),
    path('dashboard', views.jobs),
    path('jobs/add', views.add_job),
    path('jobs/create', views.create_job),
    path('jobs/<int:id>/edit', views.edit),
    path('jobs/<int:id>/update', views.update),
    path('jobs/<int:id>', views.view),
    path('jobs/<int:id>/delete', views.delete),
    path('jobs/<int:id>/add-to-user',views.add_to_user),
    path('jobs/<int:id>/remove', views.remove),
    path('jobs/<int:id>/done', views.done),
    path('logout', views.logout)
]
