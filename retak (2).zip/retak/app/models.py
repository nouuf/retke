from django.db import models

import re
import bcrypt
from datetime import datetime, timedelta

# Create your models here.

class UserManager(models.Manager):
    def register_validator(self, postData):
        errors = {}
        # [x] first_name and last_name at least 2 char
        if len(postData['first_name']) < 2:
            errors["first_name"] = "First name should be at least 2 characters"
        if len(postData['last_name']) < 2:
            errors["last_name"] = "Last name should be at least 2 characters"
        # [x] email address should be valid
        EMAIL_REGEX = re.compile(
            r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        # [x] email address needs to be unique
        check_email = User.objects.filter(email=postData['email'])
        if check_email:
            errors["email"] = "Email is already registered."
        # test whether a field matches the pattern
        if not EMAIL_REGEX.match(postData['email']):
            errors['email'] = "Email address is not in valid format"
        # [x] passwords should match
        # [x] password should be at least 8 char
       
        if len(postData['password']) < 8:
            errors["password"] = "Password needs to be at least 8 characters"
        return errors

    def login_validator(self, post_data):
        errors = {}
        EMAIL_REGEX = re.compile(
            r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        # test whether a field matches the pattern
        if not EMAIL_REGEX.match(post_data['email']):
            errors['email'] = "Invalid email format"
        # check password char len 8
        if len(post_data['password']) < 8:
            errors['password'] = "Password must be at least 8 characters, please"
        # check if email is in db
        user_list = User.objects.filter(email=post_data['email'])
        if len(user_list) == 0:
            errors['email'] = "Email was not found in db"
        elif not bcrypt.checkpw(post_data['password'].encode(), user_list[0].password.encode()):
            errors['match'] = "Password does not match the db"
        return errors

class User(models.Model):

    first_name = models.CharField(max_length=45)
    last_name = models.CharField(max_length=45)
    email = models.CharField(max_length=45, unique=True)
    password = models.CharField(max_length=100)
    # recipes
    # liked_recipes
    # tried_recipes
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager()


class JobManager(models.Manager):
    def job_validator(self, post_data):
        errors = {}

        if len(post_data['title']) < 3:
            errors['title'] = 'Title must be at least three characters long'
        
        if len(post_data['description']) < 3:
            errors['description'] = 'Description must be at least three characters long.'

        if len(post_data['location']) < 3:
            errors['location'] = 'Location must be at least three characters long'

        return errors

class Job(models.Model):
    title = models.CharField(max_length = 255)
    description = models.TextField()
    location = models.CharField(max_length = 255)
    created_by_user = models.ForeignKey(User, related_name = 'created_jobs', on_delete = models.CASCADE)
    useraddjob = models.ManyToManyField(User, related_name = 'useraddjob')
    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now = True)
    objects = JobManager()